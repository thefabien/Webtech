package service;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Hello extends HttpServlet {
    public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String username = req.getParameter("Email Address");
        String password = req.getParameter("Password");

        if ("fabianharindimana@gmail.com".equals(username) && "01234".equals(password)) {
            try {
            	res.sendRedirect("Index.html");
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {            
            res.sendRedirect("forgotpassword.html"); 
        }
    }
}
