package Service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.UsersDao;
import Model.Users;
public class UsersServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private UsersDao studentDao = new UsersDao();
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doPost(req, res);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        saveStudent(req, res);
    }
	public void saveStudent(HttpServletRequest req, HttpServletResponse res) {
		try {
			
			String studentregno = req.getParameter("regno");
			String studentfullname = req.getParameter("fullname");
			String email = req.getParameter("email");
			String password = req.getParameter("password");
			String role = req.getParameter("role");
			
			Users users = new Users();
			
			users.setRegNo(studentregno);
			users.setFirstName(studentfullname);
			users.setEmail(email);
			users.setRole(role);
			users.setPassword(password);
			
			studentDao.saveStudent(users);
			
			req.getRequestDispatcher("Login.jsp").forward(req, res);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
