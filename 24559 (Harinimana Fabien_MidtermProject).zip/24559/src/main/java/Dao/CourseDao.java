package Dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import Model.Course;
import View.HibernateUtil;

public class CourseDao {
    public void saveCourse(Course course) {
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSession().openSession();
            transaction = session.beginTransaction();
            session.save(course);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public void updateCourse(Course course) {
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSession().openSession();
            transaction = session.beginTransaction();
            session.update(course);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public void deleteCourse(Integer code) {
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSession().openSession();
            transaction = session.beginTransaction();
            Course course = session.get(Course.class, code);
            if (course != null) {
                session.delete(course);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public Course getCourseByCode(Integer code) {
        try {
            Session session = HibernateUtil.getSession().openSession();
            Course course = (Course) session
                    .createQuery("from Course where code = :code")
                    .setParameter("code", code)
                    .uniqueResult();
            session.close();
            return course;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
