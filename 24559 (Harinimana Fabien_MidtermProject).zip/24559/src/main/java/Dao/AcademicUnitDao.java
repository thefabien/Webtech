package Dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import Model.AcademicUnit;
import View.HibernateUtil;

public class AcademicUnitDao {
    public void saveAcademicUnit(AcademicUnit academicUnit) {
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSession().openSession();
            transaction = session.beginTransaction();
            session.save(academicUnit);
            transaction.commit();
            session.close();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public void updateAcademicUnit(AcademicUnit academicUnit) {
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSession().openSession();
            transaction = session.beginTransaction();
            session.update(academicUnit);
            transaction.commit();
            session.close();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public void deleteAcademicUnit(String code) {
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSession().openSession();
            transaction = session.beginTransaction();
            AcademicUnit academicUnit = session.get(AcademicUnit.class, code);
            if (academicUnit != null) {
                session.delete(academicUnit);
            }
            transaction.commit();
            session.close();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public AcademicUnit getAcademicUnitByCode(String code) {
        try {
            Session session = HibernateUtil.getSession().openSession();
            AcademicUnit academicUnit = (AcademicUnit) session
                    .createQuery("from AcademicUnit where code = :code")
                    .setParameter("code", code)
                    .uniqueResult();
            session.close();
            return academicUnit;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
