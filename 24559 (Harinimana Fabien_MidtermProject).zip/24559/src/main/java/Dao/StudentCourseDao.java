package Dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import Model.StudentCourse;
import View.HibernateUtil;

public class StudentCourseDao {

    public void saveStudentCourse(StudentCourse studentCourse) {
        Transaction transaction = null;

        try {
            Session session = HibernateUtil.getSession().openSession();
            transaction = session.beginTransaction();
            session.save(studentCourse);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public void updateStudentCourse(StudentCourse studentCourse) {
        Transaction transaction = null;

        try {
            Session session = HibernateUtil.getSession().openSession();
            transaction = session.beginTransaction();
            session.update(studentCourse);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public void deleteStudentCourse(String courseId) {
        Transaction transaction = null;

        try {
            Session session = HibernateUtil.getSession().openSession();
            transaction = session.beginTransaction();
            StudentCourse studentCourse = session.get(StudentCourse.class, courseId);
            if (studentCourse != null) {
                session.delete(studentCourse);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
}
