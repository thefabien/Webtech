package Dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import Model.CourseDefinition;
import View.HibernateUtil;

public class CourseDefinitionDao {
    
    public void saveCourseDefinition(CourseDefinition courseDefinition) {
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSession().openSession();
            transaction = session.beginTransaction();
            session.save(courseDefinition);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
    
    public void updateCourseDefinition(CourseDefinition courseDefinition) {
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSession().openSession();
            transaction = session.beginTransaction();
            session.update(courseDefinition);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
    
    public void deleteCourseDefinition(String code) {
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSession().openSession();
            transaction = session.beginTransaction();
            CourseDefinition courseDefinition = session.get(CourseDefinition.class, code);
            if (courseDefinition != null) {
                session.delete(courseDefinition);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
    
    public CourseDefinition getCourseDefinitionByCode(String code) {
        try {
            Session session = HibernateUtil.getSession().openSession();
            CourseDefinition courseDefinition = (CourseDefinition) session
                .createQuery("from CourseDefinition where code = :code")
                .setParameter("code", code)
                .uniqueResult();
            session.close();
            return courseDefinition;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
