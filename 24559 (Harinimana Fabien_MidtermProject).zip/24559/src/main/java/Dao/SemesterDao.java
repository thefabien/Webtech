package Dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import Model.Semester;
import View.HibernateUtil;

public class SemesterDao {
    
    public void saveSemester(Semester semester) {
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSession().openSession();
            transaction = session.beginTransaction();
            session.save(semester);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
    
    public void updateSemester(Semester semester) {
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSession().openSession();
            transaction = session.beginTransaction();
            session.update(semester);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
    
    public void deleteSemester(Long code) {
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSession().openSession();
            transaction = session.beginTransaction();
            Semester semester = session.get(Semester.class, code);
            if (semester != null) {
                session.delete(semester);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
    
    public Semester getSemesterByCode(Long code) {
        try {
            Session session = HibernateUtil.getSession().openSession();
            Semester semester = (Semester) session
                .createQuery("from Semester where id = :code")
                .setParameter("code", code)
                .uniqueResult();
            session.close();
            return semester;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
