package Model;

public enum Eregistration {
	PENDING,
	ADMITTED,
	REJECTED

}
