package Model;

public enum Equalification {
	MASTER,
	PHD,
	PROFESSOR

}
