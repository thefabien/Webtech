package Model;

public enum Eacademicunit {
	PROGRAM,
	FACULTY,
	DEPARTMENT

}
