package fabien.com.ferwabawebappbackendside.model;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Table(name = "matches")
@Getter
@Setter

public class Matches {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "home_team_id", nullable = false)
    private Teams homeTeam;

    @ManyToOne
    @JoinColumn(name = "away_team_id", nullable = false)
    private Teams awayTeam;

    @ManyToOne
    @JoinColumn(name = "venue_id", nullable = false)
    private Venues venue;

    @Column(nullable = false)
    private LocalDate date;

    private String result;
}
