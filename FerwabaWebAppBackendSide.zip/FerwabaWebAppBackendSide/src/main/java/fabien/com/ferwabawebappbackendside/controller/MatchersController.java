package fabien.com.ferwabawebappbackendside.controller;

import fabien.com.ferwabawebappbackendside.model.Matches;
import fabien.com.ferwabawebappbackendside.service.MatchesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/matches")  // Define base URL for match-related endpoints
public class MatchersController {

    @Autowired
    private MatchesService matchesService;

    @GetMapping
    public List<Matches> getAllMatches() {
        return matchesService.getAllMatches();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Matches> getMatchById(@PathVariable Long id) {
        Matches match = matchesService.getMatchById(id);
        return ResponseEntity.ok(match);
    }

    @PostMapping
    public ResponseEntity<Matches> createMatch(@RequestBody Matches match) {
        Matches newMatch = matchesService.createMatch(match);
        return ResponseEntity.status(HttpStatus.CREATED).body(newMatch);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Matches> updateMatch(@PathVariable Long id, @RequestBody Matches match) {
        Matches updatedMatch = matchesService.updateMatch(id, match);
        return ResponseEntity.ok(updatedMatch);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMatch(@PathVariable Long id) {
        matchesService.deleteMatch(id);
        return ResponseEntity.noContent().build();
    }
}
