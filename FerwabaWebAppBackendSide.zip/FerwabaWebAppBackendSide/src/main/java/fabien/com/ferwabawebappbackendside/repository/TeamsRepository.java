package fabien.com.ferwabawebappbackendside.repository;

import fabien.com.ferwabawebappbackendside.model.Teams;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TeamsRepository extends JpaRepository<Teams,Long> {
}
