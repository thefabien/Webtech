package fabien.com.ferwabawebappbackendside.controller;

import fabien.com.ferwabawebappbackendside.model.Teams;
import fabien.com.ferwabawebappbackendside.service.TeamsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/teams")  // Define base URL for team-related endpoints
public class TeamController {

    @Autowired
    private TeamsService teamsService;

    @GetMapping
    public List<Teams> getAllTeams() {
        return teamsService.getAllTeams();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Teams> getTeamById(@PathVariable Long id) {
        Teams team = teamsService.getTeamById(id);
        return ResponseEntity.ok(team);
    }

    @PostMapping("/create")
    public ResponseEntity<Teams> createTeam(@RequestBody Teams team) {
        Teams newTeam = teamsService.createTeam(team);
        return ResponseEntity.status(HttpStatus.CREATED).body(newTeam);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Teams> updateTeam(@PathVariable Long id, @RequestBody Teams team) {
        Teams updatedTeam = teamsService.updateTeam(id, team);
        return ResponseEntity.ok(updatedTeam);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTeam(@PathVariable Long id) {
        teamsService.deleteTeam(id);
        return ResponseEntity.noContent().build();
    }
}
