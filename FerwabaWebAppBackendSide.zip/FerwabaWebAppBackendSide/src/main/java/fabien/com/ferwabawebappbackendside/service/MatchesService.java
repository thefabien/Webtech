package fabien.com.ferwabawebappbackendside.service;

import fabien.com.ferwabawebappbackendside.model.Matches;
import org.springframework.stereotype.Service;

import java.util.List;
@Service

public interface MatchesService {
    List<Matches> getAllMatches();

    Matches getMatchById(Long id);

    Matches createMatch(Matches match);

    Matches updateMatch(Long id, Matches match);

    void deleteMatch(Long id);
}
