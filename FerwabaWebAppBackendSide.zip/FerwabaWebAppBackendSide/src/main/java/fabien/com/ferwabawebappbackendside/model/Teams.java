package fabien.com.ferwabawebappbackendside.model;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
@Getter
@Setter
@Table(name = "teams")

@Entity
public class Teams {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique = true, nullable = false)
    private String name;

    @Column(nullable = false)
    private String coach;

    @Column(nullable = false)
    private String city;

    @Column(nullable = false)
    private LocalDate founded;
}
