package fabien.com.ferwabawebappbackendside.service;

import fabien.com.ferwabawebappbackendside.model.Users;
import org.springframework.stereotype.Service;

import java.util.List;
public interface UserService {
    List<Users> getAllUsers();

    Users getUserById(Long id);

    Users createUser(Users user);

    Users updateUser(Long id, Users user);

    void deleteUser(Long id);

    Users authenticateUser(String username, String password);
}