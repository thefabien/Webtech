package fabien.com.ferwabawebappbackendside.service;

import fabien.com.ferwabawebappbackendside.model.Players;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public interface PlayersService {
    List<Players> getAllPlayers();

    Players getPlayerById(Long id);

    Players createPlayer(Players player);

    Players updatePlayer(Long id, Players player);

    void deletePlayer(Long id);
}
