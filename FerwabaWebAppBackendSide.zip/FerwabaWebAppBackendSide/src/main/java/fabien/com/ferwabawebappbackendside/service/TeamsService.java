package fabien.com.ferwabawebappbackendside.service;

import fabien.com.ferwabawebappbackendside.model.Teams;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface TeamsService {
    List<Teams> getAllTeams();

    Teams getTeamById(Long id);

    Teams createTeam(Teams team);

    Teams updateTeam(Long id, Teams team);

    void deleteTeam(Long id);
}
