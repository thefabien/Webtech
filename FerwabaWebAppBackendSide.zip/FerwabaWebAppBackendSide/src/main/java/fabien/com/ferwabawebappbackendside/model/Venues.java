package fabien.com.ferwabawebappbackendside.model;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
@Table(name = "venues")

@Setter
@Getter

@Entity
public class Venues {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String name;

    @Column(nullable = false)
    private String location;

    @Column(nullable = false)
    private Integer capacity;
}
