package fabien.com.ferwabawebappbackendside.service.impl;

import fabien.com.ferwabawebappbackendside.model.Teams;
import fabien.com.ferwabawebappbackendside.service.TeamsService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public class TeamsServiceImpl implements TeamsService {
    @Override
    public List<Teams> getAllTeams() {
        return null;
    }

    @Override
    public Teams getTeamById(Long id) {
        return null;
    }

    @Override
    public Teams createTeam(Teams team) {
        return null;
    }

    @Override
    public Teams updateTeam(Long id, Teams team) {
        return null;
    }

    @Override
    public void deleteTeam(Long id) {

    }
}
