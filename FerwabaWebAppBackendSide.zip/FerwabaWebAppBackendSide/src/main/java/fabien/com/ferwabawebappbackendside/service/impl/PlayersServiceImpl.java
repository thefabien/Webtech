package fabien.com.ferwabawebappbackendside.service.impl;

import fabien.com.ferwabawebappbackendside.model.Players;
import fabien.com.ferwabawebappbackendside.service.PlayersService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public class PlayersServiceImpl implements PlayersService {
    @Override
    public List<Players> getAllPlayers() {
        return null;
    }

    @Override
    public Players getPlayerById(Long id) {
        return null;
    }

    @Override
    public Players createPlayer(Players player) {
        return null;
    }

    @Override
    public Players updatePlayer(Long id, Players player) {
        return null;
    }

    @Override
    public void deletePlayer(Long id) {

    }
}
