package fabien.com.ferwabawebappbackendside.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Entity
@Table(name = "players")

public class Players {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long id;

    @Column(name = "first_name", nullable = false)
    private String firstName;

    @Column(name = "last_name", nullable = false)
    private String lastName;

    @ManyToOne
    @JoinColumn(name = "team_id", nullable = false)
    private Teams team;

    @Column(nullable = false)
    private String position;

    @Column(nullable = false)
    private Integer number;
}
