package fabien.com.ferwabawebappbackendside.repository;

import fabien.com.ferwabawebappbackendside.model.Matches;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MatcheRepository extends JpaRepository<Matches,Long> {
}
