package fabien.com.ferwabawebappbackendside.service;

import fabien.com.ferwabawebappbackendside.model.Venues;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public interface VenuesService {
    List<Venues> getAllVenues();

    Venues getVenueById(Long id);

    Venues createVenue(Venues venue);

    Venues updateVenue(Long id, Venues venueDetails);

    void deleteVenue(Long id);
}
