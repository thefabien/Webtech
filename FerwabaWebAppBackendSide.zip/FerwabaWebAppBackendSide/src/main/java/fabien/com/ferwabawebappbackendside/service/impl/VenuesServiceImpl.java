package fabien.com.ferwabawebappbackendside.service.impl;

import fabien.com.ferwabawebappbackendside.model.Venues;
import fabien.com.ferwabawebappbackendside.service.VenuesService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public class VenuesServiceImpl implements VenuesService {
    @Override
    public List<Venues> getAllVenues() {
        return null;
    }

    @Override
    public Venues getVenueById(Long id) {
        return null;
    }

    @Override
    public Venues createVenue(Venues venue) {
        return null;
    }

    @Override
    public Venues updateVenue(Long id, Venues venueDetails) {
        return null;
    }

    @Override
    public void deleteVenue(Long id) {

    }
}
