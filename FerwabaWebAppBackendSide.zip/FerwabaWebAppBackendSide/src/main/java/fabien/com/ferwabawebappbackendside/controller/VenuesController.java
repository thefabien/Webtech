package fabien.com.ferwabawebappbackendside.controller;

import fabien.com.ferwabawebappbackendside.model.Venues;
import fabien.com.ferwabawebappbackendside.service.VenuesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/venues")
public class VenuesController {

    @Autowired
    private VenuesService venuesService;

    @GetMapping
    public List<Venues> getAllVenues() {
        return venuesService.getAllVenues();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Venues> getVenueById(@PathVariable Long id) {
        Venues venue = venuesService.getVenueById(id);
        return ResponseEntity.ok(venue);
    }

    @PostMapping
    public ResponseEntity<Venues> createVenue(@RequestBody Venues venue) {
        Venues newVenue = venuesService.createVenue(venue);
        return ResponseEntity.ok(newVenue);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Venues> updateVenue(@PathVariable Long id, @RequestBody Venues venueDetails) {
        Venues updatedVenue = venuesService.updateVenue(id, venueDetails);
        return ResponseEntity.ok(updatedVenue);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteVenue(@PathVariable Long id) {
        venuesService.deleteVenue(id);
        return ResponseEntity.noContent().build();
    }
}
