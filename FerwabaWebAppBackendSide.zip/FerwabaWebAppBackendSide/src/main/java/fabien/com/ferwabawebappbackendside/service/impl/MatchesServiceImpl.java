package fabien.com.ferwabawebappbackendside.service.impl;

import fabien.com.ferwabawebappbackendside.model.Matches;
import fabien.com.ferwabawebappbackendside.service.MatchesService;
import org.springframework.stereotype.Service;

import java.util.List;
@Service

public class MatchesServiceImpl implements MatchesService {
    @Override
    public List<Matches> getAllMatches() {
        return null;
    }

    @Override
    public Matches getMatchById(Long id) {
        return null;
    }

    @Override
    public Matches createMatch(Matches match) {
        return null;
    }

    @Override
    public Matches updateMatch(Long id, Matches match) {
        return null;
    }

    @Override
    public void deleteMatch(Long id) {

    }
}
