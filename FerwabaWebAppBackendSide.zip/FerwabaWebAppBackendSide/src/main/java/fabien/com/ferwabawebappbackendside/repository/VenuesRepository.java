package fabien.com.ferwabawebappbackendside.repository;

import fabien.com.ferwabawebappbackendside.model.Venues;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VenuesRepository extends JpaRepository<Venues,Long> {
}
