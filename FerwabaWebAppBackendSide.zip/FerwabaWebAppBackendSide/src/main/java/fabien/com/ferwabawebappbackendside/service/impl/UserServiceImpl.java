package fabien.com.ferwabawebappbackendside.service.impl;

import fabien.com.ferwabawebappbackendside.model.Users;
import fabien.com.ferwabawebappbackendside.repository.UsersRepository;
import fabien.com.ferwabawebappbackendside.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UsersRepository userRepository;

    @Override
    public List<Users> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public Users getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    @Override
    public Users createUser(Users user) {
        return userRepository.save(user);
    }

    @Override
    public Users updateUser(Long id, Users user) {
        if (userRepository.existsById(id)) {
            user.setId(id); // ensure the user ID is set to the existing user's ID
            return userRepository.save(user);
        }
        return null;
    }

    @Override
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    @Override
    public Users authenticateUser(String username, String password) {
        Users user = userRepository.findByUsernameAndPassword(username, password);
        return user; // No need for null check, let the caller handle null if authentication fails
    }

}
