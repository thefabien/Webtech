package fabien.com.ferwabawebappbackendside.controller;

import fabien.com.ferwabawebappbackendside.model.Players;
import fabien.com.ferwabawebappbackendside.service.PlayersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/players")
public class PlayersController {

    @Autowired
    private PlayersService playersService;

    @GetMapping("/all")
    public List<Players> getAllPlayers() {
        return playersService.getAllPlayers();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Players> getPlayerById(@PathVariable Long id) {
        Players player = playersService.getPlayerById(id);
        return ResponseEntity.ok(player);
    }

    @PostMapping("/create")
    public ResponseEntity<Players> createPlayer(@RequestBody Players player) {
        Players newPlayer = playersService.createPlayer(player);
        return ResponseEntity.status(HttpStatus.CREATED).body(newPlayer);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Players> updatePlayer(@PathVariable Long id, @RequestBody Players player) {
        Players updatedPlayer = playersService.updatePlayer(id, player);
        return ResponseEntity.ok(updatedPlayer);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePlayer(@PathVariable Long id) {
        playersService.deletePlayer(id);
        return ResponseEntity.noContent().build();
    }
}
