package fabien.com.ferwabawebappbackendside.repository;

import fabien.com.ferwabawebappbackendside.model.Players;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlayersRepository extends JpaRepository<Players,Long> {
}
