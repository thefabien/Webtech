package fabien.com.ferwabawebappbackendside;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FerwabaWebAppBackendSideApplicationTests {

    @Test
    void contextLoads() {
    }

}
