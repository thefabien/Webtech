package login.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.hibernate.Session;

import util.HibernateUtil;

public class LoginDao 
{
	String sql="Select * from student where name =? and email=?";
	String Url="jdbc:mysql://localhost:3306/school";
	String username = "root";
	String password="";
	public boolean check(String name, String email) 
	{
	    try {
	        Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection con = DriverManager.getConnection(Url, username, password);
	        PreparedStatement st = con.prepareStatement(sql);
	        st.setString(1, name);  
	        st.setString(2, email); 
	        ResultSet rs = st.executeQuery();
	        if (rs.next()) {
	            return true;
	        }
	    } catch (Exception ex) {
	        ex.printStackTrace();
	    }
	    return false;
	}


}
