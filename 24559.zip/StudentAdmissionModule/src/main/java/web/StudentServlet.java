package web;

import java.io.IOException;
import java.util.List;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Student;
import dao.StudentDAO;

@WebServlet("/insert")
public class StudentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private StudentDAO studentDAO;

    @Override
    public void init() throws ServletException {
        studentDAO = new StudentDAO();
    }   

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        doGet(req, res);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String action = req.getServletPath();
        try {
            switch (action) {
                case "/new":
                    showNewForm(req, res);
                    break;
                case "/insert":
                    insertStudent(req, res);
                    break;
                case "/delete":
                    deleteStudent(req, res);
                    break;
                case "/update":
                    updateStudent(req, res);
                    break;
                default:
                    listStudent(req, res);
                    break;
            }
        } catch (Exception ex) {
            // Forward to the error page
//            req.setAttribute("exception", ex);
//            RequestDispatcher dispatcher = req.getRequestDispatcher("Error.jsp");
//            dispatcher.forward(req, res);
        	throw new ServletException(ex);
        	
        }
    }
    private void listStudent(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        List<Student> listStudents = studentDAO.allStudent();
        req.setAttribute("liststudent", listStudents);
        RequestDispatcher dispatcher = req.getRequestDispatcher("student-list.jsp");
        dispatcher.forward(req, res);
    }

    private void showNewForm(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = req.getRequestDispatcher("student-form.jsp");
        dispatcher.forward(req, res);
    }
    

    private void insertStudent(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String country = req.getParameter("country");
        Student newStudent = new Student(0, name, email, country);
        studentDAO.saveStudent(newStudent);
       // res.sendRedirect(country);
    }

    private void deleteStudent(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        Student student = new Student(id);
        studentDAO.deleteStudent(student);
       // res.sendRedirect(getServletInfo());
    }

    private void updateStudent(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String country = req.getParameter("country");
        Student student = new Student(id, name, email, country);
        studentDAO.updateStudent(student);
       // res.sendRedirect(country);
    }

    
}  
