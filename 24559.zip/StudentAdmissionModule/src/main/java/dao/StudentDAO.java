package dao;
import java.util.List;
import model.Student;
import org.hibernate.Session;
import util.HibernateUtil;
import org.hibernate.Transaction;

public class StudentDAO {
	public Student saveStudent(Student theStudent){
        try{
            Session ss=HibernateUtil.getSessionFactory().openSession();
            ss.save(theStudent);
            ss.beginTransaction().commit();
            ss.close();
            
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return null;
    }
	public Student updateStudent(Student theStudent){
        try{
            Session ss=HibernateUtil.getSessionFactory().openSession();
            ss.update(theStudent);
            ss.beginTransaction().commit();
            ss.close();
            
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return null;
    }
	public Student deleteStudent(Student theStudent){
        try{
            Session ss=HibernateUtil.getSessionFactory().openSession();
            ss.delete(theStudent);
            ss.beginTransaction().commit();
            ss.close();
            
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return null;
    }
	public List<Student> allStudent(){
		Transaction transaction =null;
		List<Student> listOfStudent = null;
        try{
            Session ss=HibernateUtil.getSessionFactory().openSession();{
            	transaction = ss.beginTransaction();
            	listOfStudent = ss.createQuery("from Student").getResultList();
            	transaction.commit();
            }
//            List<Student> theStudent = ss.createQuery("select theStudent from Student theStudent").list();
//            ss.close();
//            return theStudent;
        }catch(Exception ex){
        	if (transaction != null) {
        		transaction.rollback();
				
			}
        ex.printStackTrace();
        }
        return listOfStudent;
    }

}
 